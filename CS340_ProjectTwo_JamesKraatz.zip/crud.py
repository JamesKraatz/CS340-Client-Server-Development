from pymongo import MongoClient
from pymongo import UpdateOne
from pymongo import DeleteOne
from pymongo import InsertOne
from pymongo import UpdateMany
from pymongo import DeleteMany
from bson.objectid import ObjectId

class CRUD(object):
    """ CRUD operations for Animal collection in MongoDB """
    """client = ""
    url = ""
    port = ""
    myDb = ""
    myCol = ""
    user = ""
    password = ""
    """
    
    #constructor
    def __init__(self, db, col, usr, passwd, url, port):
        # init to connect to mongodb without authentication
        self.client = MongoClient('mongodb://%s:%s@%s:%s/%s' \
        %(usr, passwd, url, port, db))
        self.myDb = self.client[db]
        self.myCol = self.myDb[col]
        
    # CREATE method of CRUD
    def create(self, data):
        if data is not None:
            result = self.myCol.insert_one(data) # inserts data into database.collection
            return result.acknowledged
        else:
            raise Exception("Nothing to save, data parameter is empty")
            
    # READ method of CRUD
    """ Reads all data from self.database.collection that matches query """
    def readOne(self, query):
        if query is not None:
            # Return cursor used to iterate through documents matching query
            cursor = self.myCol.find_One(query)
            return cursor
        else:
            raise Exception("No query provided for docment search")
            return None

    def readAll(self, query):
        if query is not None:
            # Return cursor used to iterate through documents matching query
            cursor = self.myCol.find(query, { '_id':False })
            return cursor
        else:
            raise Exception("No query provided for docment search")
            return None

    # UPDATE method of CRUD
    """ Updates documents matching criteria with newValues """
    def updateOne(self, query, newValues):
        if query is not None and newValues is not None:
            updateResult = self.myCol.update_one(query, newValues)
            return updateResult
        else:
            raise Exception("Both query and newValues are needed to update")
            return None
        
    def updateMany(self, query, newValues):
        if query is not None and newValues is not None:
            updateResult = self.myCol.update_many(query, newValues)
            return updateResult
        else:
            raise Exception("Both query and newValues are needed to update")
            return null
    
    # DELET method of CRUD
    def deleteOne(self, filter):
        if filter is not None:
            deleteResult = self.myCol.delete_one(filter)
            return deleteResult
        else:
            raise Exception("A filter is required to find and delete a document")
            return None
        
    def deleteMany(self, filter):
        if filter is not None:
            deleteResult = self.myCol.delete_many(filter)
            return deleteResult
        else:
            raise Exception("a filter is requred to find and delete a document")
            return None